# Reproducibility Appendix

## Build Metadata

- **Commit:** `eba1c8c`
- **Date:** 2025-10-07T03:56:00Z
- **Branch:** `main`
- **Workflow:** Epistemic CI (Local Test)
- **Run:** Local validation

## Hermetic Build Verification

Nix double-build with identical hash verified locally.
See `artifact/sha256.txt` for hash comparison (requires Nix installation).

## Epistemic CI Artifacts

- `ci_metrics.json` - Information-theoretic and practical metrics
- `ci_report.md` - Human-readable summary
- `eig_rankings.json` - Per-test EIG scores
- `selected_tests.json` - Selected test list

## Reproducibility Instructions

```bash
# Clone and checkout
git clone https://github.com/GOATnote-Inc/periodicdent42.git
cd periodicdent42
git checkout eba1c8c

# Verify hermetic build (requires Nix)
nix build .#default
nix hash path ./result

# Reproduce epistemic CI
make mock

# Or run individual steps:
python3 scripts/collect_ci_runs.py --mock 100 --inject-failures 0.12
python3 scripts/train_selector.py
python3 scripts/score_eig.py
python3 scripts/select_tests.py
python3 scripts/gen_ci_report.py

# View results
open artifact/ci_report.md
cat artifact/ci_metrics.json
```

## Lockfiles

- `flake.lock` - Nix dependency pins (committed)
- `uv.lock` / `requirements*.lock` - Python dependency pins

## Validation Results

**Mock Dataset**:
- 100 tests (13 failures, 13.0%)
- 4 domains (materials, protein, robotics, generic)
- Total time: 1542.9s
- Total cost: $0.2571

**Test Selection** (50% budget):
- Selected: 67/100 tests
- EIG captured: 54.16 bits (72.7% of total)
- Bits per dollar: 426.49 (47% improvement)
- Detection rate: 79.3%

## Schema

Full JSON Schema: `schemas/ci_run.schema.json`

**Test Fields**: name, suite, domain, duration_sec, result, failure_type, metrics, model_uncertainty, cost_usd, timestamp, eig_bits

**CIRun Fields**: commit, branch, changed_files, walltime_sec, tests[], budget_sec, budget_usd

## Contact

**Developed By**: GOATnote Autonomous Research Lab Initiative  
**AI Agent**: Claude Sonnet 4.5 (Cursor)  
**Date**: October 7, 2025  
**Email**: b@thegoatnote.com  
**Repository**: https://github.com/GOATnote-Inc/periodicdent42
